"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @frontegg/nextjs/pages */ \"@frontegg/nextjs/pages\");\n/* harmony import */ var _frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction CustomApp({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/_app.tsx\",\n        lineNumber: 4,\n        columnNumber: 10\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_1__.withFronteggApp)(CustomApp, {\n    hostedLoginBox: true,\n    authOptions: {\n    }\n}));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0FBQXlEO0FBRXpELFNBQVNDLFVBQVUsRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUNyRCxxQkFBTyw4REFBQ0Q7UUFBVyxHQUFHQyxTQUFTOzs7Ozs7QUFDakM7QUFFQSxpRUFBZUgsdUVBQWVBLENBQUNDLFdBQVc7SUFDeENHLGdCQUFnQixJQUFJO0lBQ3BCQyxhQUFhO0lBRWI7QUFDRixFQUFFLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtaG9zdGVkLy4vcGFnZXMvX2FwcC50c3g/MmZiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB3aXRoRnJvbnRlZ2dBcHAgfSBmcm9tIFwiQGZyb250ZWdnL25leHRqcy9wYWdlc1wiO1xuXG5mdW5jdGlvbiBDdXN0b21BcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICByZXR1cm4gPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgd2l0aEZyb250ZWdnQXBwKEN1c3RvbUFwcCwge1xuICBob3N0ZWRMb2dpbkJveDogdHJ1ZSxcbiAgYXV0aE9wdGlvbnM6IHtcbiAgICAvLyBrZWVwU2Vzc2lvbkFsaXZlOiB0cnVlLCAvLyBVbmNvbW1lbnQgdGhpcyBpbiBvcmRlciB0byBtYWludGFpbiB0aGUgc2Vzc2lvbiBhbGl2ZVxuICB9LFxufSk7Il0sIm5hbWVzIjpbIndpdGhGcm9udGVnZ0FwcCIsIkN1c3RvbUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImhvc3RlZExvZ2luQm94IiwiYXV0aE9wdGlvbnMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "@frontegg/nextjs/pages":
/*!*****************************************!*\
  !*** external "@frontegg/nextjs/pages" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("@frontegg/nextjs/pages");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();