"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _frontegg_nextjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @frontegg/nextjs */ \"@frontegg/nextjs\");\n/* harmony import */ var _frontegg_nextjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_frontegg_nextjs__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nfunction MyPage({ products  }) {\n    const { user  } = (0,_frontegg_nextjs__WEBPACK_IMPORTED_MODULE_2__.useAuth)();\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();\n    const logout = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{\n        router.replace(\"/account/logout\");\n    }, [\n        router\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                children: \"My Page\"\n            }, void 0, false, {\n                fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this),\n            products,\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                    src: user?.profilePictureUrl,\n                    alt: user?.name\n                }, void 0, false, {\n                    fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                    lineNumber: 21,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                lineNumber: 20,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                    children: [\n                        \"Logged in as: \",\n                        user?.name\n                    ]\n                }, void 0, true, {\n                    fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                    lineNumber: 24,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                lineNumber: 23,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: logout,\n                    children: \"Log out\"\n                }, void 0, false, {\n                    fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                    lineNumber: 27,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/Users/roy/Desktop/frontegg-demos/nextjs/nextjs-hosted/pages/index.tsx\",\n        lineNumber: 17,\n        columnNumber: 5\n    }, this);\n} // In the `getServerSideProps` method you can get data from an external service to pull relevant data for a logged in user.\n // we used the prop `products`. See the commented code for an example.\n // export const getServerSideProps: GetServerSideProps = withSSRSession(\n //   async (context, session) => {\n //     //     const { data } = await fetch('{external}/product', {\n //     //      headers: {\n //     //        Authorization: 'bearer ' + session.accessToken,\n //     //      },\n //     //    });\n //     return { props: {} };\n //   }\n // );\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUE7QUFBb0M7QUFHTztBQUNKO0FBRXhCLFNBQVNHLE9BQU8sRUFBRUMsU0FBUSxFQUFFLEVBQUU7SUFDM0MsTUFBTSxFQUFFQyxLQUFJLEVBQUUsR0FBR0oseURBQU9BO0lBRXhCLE1BQU1LLFNBQVNKLHNEQUFTQTtJQUV4QixNQUFNSyxTQUFTUCxrREFBV0EsQ0FBQyxJQUFNO1FBQy9CTSxPQUFPRSxPQUFPLENBQUM7SUFDakIsR0FBRztRQUFDRjtLQUFPO0lBRVgscUJBQ0UsOERBQUNHOzswQkFDQyw4REFBQ0M7MEJBQUc7Ozs7OztZQUNITjswQkFDRCw4REFBQ0s7MEJBQ0MsNEVBQUNFO29CQUFJQyxLQUFLUCxNQUFNUTtvQkFBbUJDLEtBQUtULE1BQU1VOzs7Ozs7Ozs7OzswQkFFaEQsOERBQUNOOzBCQUNDLDRFQUFDTzs7d0JBQUs7d0JBQWVYLE1BQU1VOzs7Ozs7Ozs7Ozs7MEJBRTdCLDhEQUFDTjswQkFDQyw0RUFBQ1E7b0JBQU9DLFNBQVNYOzhCQUFROzs7Ozs7Ozs7Ozs7Ozs7OztBQUlqQyxDQUFDLENBRUQsMkhBQTJIO0NBQzNILHNFQUFzRTtDQUV0RSx3RUFBd0U7Q0FDeEUsa0NBQWtDO0NBQ2xDLGtFQUFrRTtDQUNsRSx5QkFBeUI7Q0FDekIsZ0VBQWdFO0NBQ2hFLGlCQUFpQjtDQUNqQixnQkFBZ0I7Q0FDaEIsNEJBQTRCO0NBQzVCLE1BQU07Q0FDTixLQUFLIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dGpzLWhvc3RlZC8uL3BhZ2VzL2luZGV4LnRzeD8wN2ZmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBHZXRTZXJ2ZXJTaWRlUHJvcHMgfSBmcm9tIFwibmV4dFwiO1xuaW1wb3J0IHsgZ2V0U2Vzc2lvbiB9IGZyb20gXCJAZnJvbnRlZ2cvbmV4dGpzL3BhZ2VzXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIkBmcm9udGVnZy9uZXh0anNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE15UGFnZSh7IHByb2R1Y3RzIH0pIHtcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XG5cbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cbiAgY29uc3QgbG9nb3V0ID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJvdXRlci5yZXBsYWNlKCcvYWNjb3VudC9sb2dvdXQnKTtcbiAgfSwgW3JvdXRlcl0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMT5NeSBQYWdlPC9oMT5cbiAgICAgIHtwcm9kdWN0c31cbiAgICAgIDxkaXY+XG4gICAgICAgIDxpbWcgc3JjPXt1c2VyPy5wcm9maWxlUGljdHVyZVVybH0gYWx0PXt1c2VyPy5uYW1lfSAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8c3Bhbj5Mb2dnZWQgaW4gYXM6IHt1c2VyPy5uYW1lfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtsb2dvdXR9PkxvZyBvdXQ8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vLyBJbiB0aGUgYGdldFNlcnZlclNpZGVQcm9wc2AgbWV0aG9kIHlvdSBjYW4gZ2V0IGRhdGEgZnJvbSBhbiBleHRlcm5hbCBzZXJ2aWNlIHRvIHB1bGwgcmVsZXZhbnQgZGF0YSBmb3IgYSBsb2dnZWQgaW4gdXNlci5cbi8vIHdlIHVzZWQgdGhlIHByb3AgYHByb2R1Y3RzYC4gU2VlIHRoZSBjb21tZW50ZWQgY29kZSBmb3IgYW4gZXhhbXBsZS5cblxuLy8gZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wczogR2V0U2VydmVyU2lkZVByb3BzID0gd2l0aFNTUlNlc3Npb24oXG4vLyAgIGFzeW5jIChjb250ZXh0LCBzZXNzaW9uKSA9PiB7XG4vLyAgICAgLy8gICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgZmV0Y2goJ3tleHRlcm5hbH0vcHJvZHVjdCcsIHtcbi8vICAgICAvLyAgICAgIGhlYWRlcnM6IHtcbi8vICAgICAvLyAgICAgICAgQXV0aG9yaXphdGlvbjogJ2JlYXJlciAnICsgc2Vzc2lvbi5hY2Nlc3NUb2tlbixcbi8vICAgICAvLyAgICAgIH0sXG4vLyAgICAgLy8gICAgfSk7XG4vLyAgICAgcmV0dXJuIHsgcHJvcHM6IHt9IH07XG4vLyAgIH1cbi8vICk7Il0sIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlQXV0aCIsInVzZVJvdXRlciIsIk15UGFnZSIsInByb2R1Y3RzIiwidXNlciIsInJvdXRlciIsImxvZ291dCIsInJlcGxhY2UiLCJkaXYiLCJoMSIsImltZyIsInNyYyIsInByb2ZpbGVQaWN0dXJlVXJsIiwiYWx0IiwibmFtZSIsInNwYW4iLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "@frontegg/nextjs":
/*!***********************************!*\
  !*** external "@frontegg/nextjs" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@frontegg/nextjs");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();