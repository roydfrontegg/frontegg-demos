"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/[...frontegg-router]";
exports.ids = ["pages/[...frontegg-router]"];
exports.modules = {

/***/ "./pages/[...frontegg-router].tsx":
/*!****************************************!*\
  !*** ./pages/[...frontegg-router].tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var _frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @frontegg/nextjs/pages */ \"@frontegg/nextjs/pages\");\n/* harmony import */ var _frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_0__);\n\nconst getServerSideProps = _frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_0__.FronteggRouterProps;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_frontegg_nextjs_pages__WEBPACK_IMPORTED_MODULE_0__.FronteggRouter);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9bLi4uZnJvbnRlZ2ctcm91dGVyXS50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUE2RTtBQUV0RSxNQUFNRSxxQkFBcUJELHVFQUFtQkEsQ0FBQztBQUN0RCxpRUFBZUQsa0VBQWNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtaG9zdGVkLy4vcGFnZXMvWy4uLmZyb250ZWdnLXJvdXRlcl0udHN4PzQ3N2UiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJvbnRlZ2dSb3V0ZXIsIEZyb250ZWdnUm91dGVyUHJvcHMgfSBmcm9tICdAZnJvbnRlZ2cvbmV4dGpzL3BhZ2VzJztcblxuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IEZyb250ZWdnUm91dGVyUHJvcHM7XG5leHBvcnQgZGVmYXVsdCBGcm9udGVnZ1JvdXRlcjsiXSwibmFtZXMiOlsiRnJvbnRlZ2dSb3V0ZXIiLCJGcm9udGVnZ1JvdXRlclByb3BzIiwiZ2V0U2VydmVyU2lkZVByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/[...frontegg-router].tsx\n");

/***/ }),

/***/ "@frontegg/nextjs/pages":
/*!*****************************************!*\
  !*** external "@frontegg/nextjs/pages" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("@frontegg/nextjs/pages");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/[...frontegg-router].tsx"));
module.exports = __webpack_exports__;

})();