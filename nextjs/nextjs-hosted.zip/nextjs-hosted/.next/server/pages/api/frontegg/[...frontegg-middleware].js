"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/frontegg/[...frontegg-middleware]";
exports.ids = ["pages/api/frontegg/[...frontegg-middleware]"];
exports.modules = {

/***/ "@frontegg/nextjs/middleware":
/*!**********************************************!*\
  !*** external "@frontegg/nextjs/middleware" ***!
  \**********************************************/
/***/ ((module) => {

module.exports = require("@frontegg/nextjs/middleware");

/***/ }),

/***/ "(api)/./pages/api/frontegg/[...frontegg-middleware].ts":
/*!********************************************************!*\
  !*** ./pages/api/frontegg/[...frontegg-middleware].ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"config\": () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _frontegg_nextjs_middleware__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @frontegg/nextjs/middleware */ \"@frontegg/nextjs/middleware\");\n/* harmony import */ var _frontegg_nextjs_middleware__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_frontegg_nextjs_middleware__WEBPACK_IMPORTED_MODULE_0__);\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_frontegg_nextjs_middleware__WEBPACK_IMPORTED_MODULE_0__.FronteggApiMiddleware);\nconst config = {\n    api: {\n        externalResolver: true,\n        // https://nextjs.org/docs/messages/api-routes-response-size-limit\n        responseLimit: false\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZnJvbnRlZ2cvWy4uLmZyb250ZWdnLW1pZGRsZXdhcmVdLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBb0U7QUFFcEUsaUVBQWVBLDhFQUFxQkEsRUFBQztBQUM5QixNQUFNQyxTQUFTO0lBQ3BCQyxLQUFLO1FBQ0hDLGtCQUFrQixJQUFJO1FBQ3RCLGtFQUFrRTtRQUNsRUMsZUFBZSxLQUFLO0lBQ3RCO0FBQ0YsRUFBRSIsInNvdXJjZXMiOlsid2VicGFjazovL25leHRqcy1ob3N0ZWQvLi9wYWdlcy9hcGkvZnJvbnRlZ2cvWy4uLmZyb250ZWdnLW1pZGRsZXdhcmVdLnRzPzYzZmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRnJvbnRlZ2dBcGlNaWRkbGV3YXJlIH0gZnJvbSAnQGZyb250ZWdnL25leHRqcy9taWRkbGV3YXJlJztcblxuZXhwb3J0IGRlZmF1bHQgRnJvbnRlZ2dBcGlNaWRkbGV3YXJlO1xuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IHtcbiAgYXBpOiB7XG4gICAgZXh0ZXJuYWxSZXNvbHZlcjogdHJ1ZSxcbiAgICAvLyBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9hcGktcm91dGVzLXJlc3BvbnNlLXNpemUtbGltaXRcbiAgICByZXNwb25zZUxpbWl0OiBmYWxzZSxcbiAgfSxcbn07Il0sIm5hbWVzIjpbIkZyb250ZWdnQXBpTWlkZGxld2FyZSIsImNvbmZpZyIsImFwaSIsImV4dGVybmFsUmVzb2x2ZXIiLCJyZXNwb25zZUxpbWl0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/frontegg/[...frontegg-middleware].ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/frontegg/[...frontegg-middleware].ts"));
module.exports = __webpack_exports__;

})();