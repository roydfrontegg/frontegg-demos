import { FronteggRouter, FronteggRouterProps } from '@frontegg/nextjs/pages';

export const getServerSideProps = FronteggRouterProps;
export default FronteggRouter;